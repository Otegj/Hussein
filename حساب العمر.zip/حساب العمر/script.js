function calculateAge() {
    const dobInput = document.getElementById("dob").value;
    const resultElement = document.getElementById("result");

    if (!dobInput) {
        resultElement.innerText = "الرجاء إدخال تاريخ ميلادك";
        return;
    }

    const dob = new Date(dobInput);
    const today = new Date();

    let years = today.getFullYear() - dob.getFullYear();
    let months = today.getMonth() - dob.getMonth();
    let days = today.getDate() - dob.getDate();

    // تصحيح النقص في الأيام والشهور
    if (days < 0) {
        months--;
        const lastMonth = new Date(today.getFullYear(), today.getMonth(), 0).getDate();
        days += lastMonth;
    }

    if (months < 0) {
        years--;
        months += 12;
    }

    resultElement.innerText = `عمرك الحالي: ${years} سنة و ${months} شهر و ${days} يوم.`;
}

function resetCalculator() {
    document.getElementById("dob").value = "";
    document.getElementById("result").innerText = "";
}